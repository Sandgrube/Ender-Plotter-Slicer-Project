# Ender Plotter Slicer

Qt-basierte Desktop-Anwendung für 2D-Layout, Text-zu-Pfad, SVG-Import und G-Code-Erzeugung für einen als Pen-Plotter umgebauten Ender 3.

## Start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Hinweise

- Text wird über Vektorpfade erzeugt, nicht gerastert.
- SVG-Elemente werden geparst und in Polylinien überführt.
- G-Code verwendet Z-basierte Pen-Up/Pen-Down-Logik mit zusätzlichem Retract.
- Das Projektformat ist JSON-basiert (`*.plotproj.json`).
